'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:studentDashboardCtrl
 * @description
 * # StudentDashboardCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('studentDashboardController', function () {
  });
