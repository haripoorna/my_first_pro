'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:editStudentInfoCtrl
 * @description
 * # EditStudentInfoCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('editStudentInfoController', function () {
  });
