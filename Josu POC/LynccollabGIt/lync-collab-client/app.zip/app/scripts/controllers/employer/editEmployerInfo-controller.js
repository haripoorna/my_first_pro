'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:editEmployerInfoCtrl
 * @description
 * # EditEmployerInfoCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('editEmployerInfoController', function () {
  });
