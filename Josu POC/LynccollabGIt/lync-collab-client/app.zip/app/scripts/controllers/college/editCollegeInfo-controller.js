'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:editCollegeInfoCtrl
 * @description
 * # EditCollegeInfoCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('editCollegeInfoController', function () {
  });
