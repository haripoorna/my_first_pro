'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:collegeDashboardCtrl
 * @description
 * # CollegeDashboardCtrl
 * Controller of the lyncSchoolApp
 */


angular.module('lyncSchoolApp')
    .controller('collegeDashboardController', ['$scope', function(scope) {
    
    }]);