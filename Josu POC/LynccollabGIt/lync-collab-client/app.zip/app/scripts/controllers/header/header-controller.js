'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:headerController
 * @description
 * # HeaderController
 * Controller of the lyncSchoolApp
 */

angular.module('lyncSchoolApp').controller('headerController', function() {
	
});