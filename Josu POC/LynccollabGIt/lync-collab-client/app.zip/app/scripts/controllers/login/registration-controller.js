'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:registrationCtrl
 * @description
 * # RegistrationCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('registrationController', function () {
  });
