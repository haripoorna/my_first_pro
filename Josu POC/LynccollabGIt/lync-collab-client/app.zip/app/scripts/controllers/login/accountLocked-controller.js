'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:accountLocked
 * @description
 * # AccountLocked
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('accountLockedController', function () {
  });
