'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:loginCtrl
 * @description
 * # LoginCtrl
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('loginController', function () {
  });
