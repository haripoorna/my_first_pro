'use strict';

/**
 * @ngdoc function
 * @name lyncSchoolApp.controller:forgotPassword
 * @description
 * # ForgotPassword
 * Controller of the lyncSchoolApp
 */
 
angular.module('lyncSchoolApp')
  .controller('forgotPasswordController', function () {
  });
